#!/bin/bash
set -e

# OmniCloud Quick Install/Upgrade Script
# Can be run with: curl -fsSL http://dcp1.omniplex.services:10858/install | sudo bash
# Or with environment variables:
#   curl -fsSL http://dcp1.omniplex.services:10858/install | sudo REGISTRATION_KEY=xxx MAIN_SERVER_URL=http://server:10858 bash

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Main server URL (use domain name)
MAIN_SERVER="${MAIN_SERVER_URL:-http://dcp1.omniplex.services:10858}"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}Error: This script must be run as root (use sudo)${NC}"
    exit 1
fi

echo "=========================================="
echo -e "${BLUE}OmniCloud DCP Manager - Quick Install${NC}"
echo "=========================================="
echo ""

# Detect if this is an upgrade or fresh install
if [ -f /opt/omnicloud/bin/omnicloud ]; then
    INSTALL_TYPE="upgrade"
    echo -e "${YELLOW}Existing installation detected - will upgrade${NC}"
else
    INSTALL_TYPE="install"
    echo -e "${GREEN}Fresh installation${NC}"
fi

# Detect OS
if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS=$ID
    VER=$VERSION_ID
else
    echo -e "${RED}Error: Cannot detect OS${NC}"
    exit 1
fi

echo -e "${GREEN}Detected OS: $OS $VER${NC}"
echo ""

# Step 1: Get latest version info
echo "[1/10] Fetching latest version from ${MAIN_SERVER}..."
LATEST_VERSION=$(curl -fsSL "${MAIN_SERVER}/api/v1/versions/latest" | grep -o '"version":"[^"]*"' | cut -d'"' -f4)
if [ -z "$LATEST_VERSION" ]; then
    echo -e "${RED}Error: Could not fetch latest version from ${MAIN_SERVER}${NC}"
    echo "Make sure the main server is reachable and the /api/v1/versions/latest endpoint is working"
    exit 1
fi
echo -e "${GREEN}✓ Latest version: ${LATEST_VERSION}${NC}"

# Check current version if upgrading
if [ "$INSTALL_TYPE" = "upgrade" ] && [ -f /etc/omnicloud/version ]; then
    CURRENT_VERSION=$(cat /etc/omnicloud/version)
    echo -e "${BLUE}Current version: ${CURRENT_VERSION}${NC}"
    if [ "$CURRENT_VERSION" = "$LATEST_VERSION" ]; then
        echo -e "${GREEN}Already running latest version!${NC}"
        echo "Re-run with FORCE=1 to reinstall: sudo FORCE=1 $0"
        if [ -z "${FORCE:-}" ]; then
            exit 0
        fi
        echo -e "${YELLOW}FORCE=1 detected, proceeding with reinstall...${NC}"
    fi
fi

# Step 2: Download release tarball
echo ""
echo "[2/10] Downloading OmniCloud v${LATEST_VERSION}..."
DOWNLOAD_URL="${MAIN_SERVER}/releases/omnicloud-${LATEST_VERSION}-linux-amd64.tar.gz"
TMP_DIR=$(mktemp -d)
trap "rm -rf $TMP_DIR" EXIT

cd "$TMP_DIR"
if ! curl -fsSL -o omnicloud.tar.gz "$DOWNLOAD_URL"; then
    echo -e "${RED}Error: Failed to download from ${DOWNLOAD_URL}${NC}"
    exit 1
fi
echo -e "${GREEN}✓ Downloaded${NC}"

# Step 3: Extract tarball
echo ""
echo "[3/10] Extracting archive..."
tar -xzf omnicloud.tar.gz
EXTRACT_DIR=$(find . -maxdepth 1 -type d -name "omnicloud-*" | head -1)
if [ -z "$EXTRACT_DIR" ]; then
    echo -e "${RED}Error: Could not find extracted directory${NC}"
    exit 1
fi
cd "$EXTRACT_DIR"
echo -e "${GREEN}✓ Extracted to ${TMP_DIR}/${EXTRACT_DIR}${NC}"

# Step 4: Check prerequisites (skip if upgrading)
if [ "$INSTALL_TYPE" = "install" ]; then
    echo ""
    echo "[4/10] Checking prerequisites..."

    # Check for systemd
    if ! command -v systemctl &> /dev/null; then
        echo -e "${RED}Error: systemd is required but not found${NC}"
        exit 1
    fi
    echo -e "${GREEN}✓ Systemd found${NC}"
else
    echo ""
    echo "[4/10] Skipping prerequisites check (upgrade mode)"
fi

# Step 5: Install PostgreSQL (skip if exists or upgrading)
echo ""
echo "[5/10] Checking PostgreSQL..."
if ! command -v psql &> /dev/null; then
    if [ "$INSTALL_TYPE" = "upgrade" ]; then
        echo -e "${RED}Error: PostgreSQL not found but this is an upgrade. Something is wrong.${NC}"
        exit 1
    fi

    echo -e "${YELLOW}PostgreSQL not found. Installing...${NC}"
    case "$OS" in
        ubuntu|debian)
            apt-get update -qq
            apt-get install -y postgresql postgresql-contrib curl
            ;;
        centos|rhel|fedora)
            dnf install -y postgresql-server postgresql-contrib curl
            postgresql-setup --initdb
            ;;
        *)
            echo -e "${RED}Error: Unsupported OS for auto-install: $OS${NC}"
            echo "Please install PostgreSQL 12+ manually"
            exit 1
            ;;
    esac
    systemctl enable postgresql
    systemctl start postgresql

    # Wait for PostgreSQL to be ready
    for i in 1 2 3 4 5 6 7 8 9 10; do
        if sudo -u postgres psql -d postgres -c "SELECT 1" &>/dev/null; then
            break
        fi
        echo "  Waiting for PostgreSQL to accept connections..."
        sleep 2
    done
    echo -e "${GREEN}✓ PostgreSQL installed${NC}"
else
    echo -e "${GREEN}✓ PostgreSQL found${NC}"
fi

# Step 6: Create system user (skip if exists)
echo ""
echo "[6/10] Setting up system user..."
if ! id "omnicloud" &>/dev/null; then
    useradd -r -s /bin/false -d /opt/omnicloud -m omnicloud
    echo -e "${GREEN}✓ User 'omnicloud' created${NC}"
else
    echo -e "${GREEN}✓ User 'omnicloud' already exists${NC}"
fi

# Create directories
mkdir -p /opt/omnicloud/bin
mkdir -p /opt/omnicloud/data/torrents
mkdir -p /opt/OmniCloud/omnicloud2024
mkdir -p /var/log/omnicloud
mkdir -p /etc/omnicloud
mkdir -p /library/omnicloud
chown -R omnicloud:omnicloud /opt/omnicloud
chown -R omnicloud:omnicloud /opt/OmniCloud 2>/dev/null || true
chown -R omnicloud:omnicloud /var/log/omnicloud
chown -R omnicloud:omnicloud /library/omnicloud 2>/dev/null || true

# Step 7: Setup database (skip if exists)
echo ""
echo "[7/10] Setting up database..."

if sudo -u postgres psql -d postgres -lqt | cut -d \| -f 1 | grep -qw OmniCloud; then
    echo -e "${GREEN}✓ Database 'OmniCloud' already exists${NC}"
    # Read existing password from config
    DB_PASSWORD=""
    if [ -f /opt/omnicloud/auth.config ]; then
        DB_PASSWORD=$(grep "^password=" /opt/omnicloud/auth.config | cut -d'=' -f2)
    elif [ -f /opt/OmniCloud/omnicloud2024/omnicloud.config ]; then
        DB_PASSWORD=$(grep "^password=" /opt/OmniCloud/omnicloud2024/omnicloud.config | cut -d'=' -f2)
    fi

    if [ -n "$DB_PASSWORD" ]; then
        # Verify the password actually works
        if PGPASSWORD="$DB_PASSWORD" psql -h localhost -U omni -d OmniCloud -c "SELECT 1" &>/dev/null; then
            echo -e "${GREEN}✓ Using existing database password (verified)${NC}"
        else
            echo -e "${YELLOW}⚠  Existing password doesn't work, resetting...${NC}"
            DB_PASSWORD=$(openssl rand -base64 32 | tr -d "=+/" | cut -c1-25)
            sudo -u postgres psql -d postgres -c "ALTER USER omni WITH PASSWORD '$DB_PASSWORD';" 2>&1 | grep -v "could not change directory" || true
            echo -e "${GREEN}✓ Database password reset${NC}"
            FORCE_NEW_CONFIG=1
        fi
    else
        # No password found (missing config or empty password) - generate new one and reset in postgres
        echo -e "${YELLOW}⚠  No database password found in config, generating new one...${NC}"
        DB_PASSWORD=$(openssl rand -base64 32 | tr -d "=+/" | cut -c1-25)
        sudo -u postgres psql -d postgres -c "ALTER USER omni WITH PASSWORD '$DB_PASSWORD';" 2>&1 | grep -v "could not change directory" || true
        echo -e "${GREEN}✓ Database password set${NC}"
        FORCE_NEW_CONFIG=1

        # Run migrations in case they haven't been applied
        echo "  Running database migrations..."
        for migration in migrations/*.sql; do
            if [ -f "$migration" ]; then
                echo "    $(basename $migration)"
                PGPASSWORD="$DB_PASSWORD" psql -h localhost -U omni -d OmniCloud -f "$migration" -q 2>&1 | grep -v "could not change directory" || true
            fi
        done
        echo -e "${GREEN}✓ Migrations completed${NC}"
    fi
else
    # Fresh database setup
    DB_PASSWORD=$(openssl rand -base64 32 | tr -d "=+/" | cut -c1-25)

    sudo -u postgres psql -v ON_ERROR_STOP=1 -d postgres <<EOSQL
CREATE USER omni WITH PASSWORD '$DB_PASSWORD';
CREATE DATABASE "OmniCloud" OWNER omni;
EOSQL

    sudo -u postgres psql -v ON_ERROR_STOP=1 -d OmniCloud <<EOSQL
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
GRANT ALL PRIVILEGES ON DATABASE "OmniCloud" TO omni;
EOSQL

    echo -e "${GREEN}✓ Database 'OmniCloud' created${NC}"

    # Run migrations
    echo "  Running database migrations..."
    for migration in migrations/*.sql; do
        if [ -f "$migration" ]; then
            echo "    $(basename $migration)"
            PGPASSWORD="$DB_PASSWORD" psql -h localhost -U omni -d OmniCloud -f "$migration" -q 2>&1 | grep -v "could not change directory" || true
        fi
    done
    echo -e "${GREEN}✓ Migrations completed${NC}"
fi

# Step 8: Stop service if running (for upgrade)
if [ "$INSTALL_TYPE" = "upgrade" ]; then
    echo ""
    echo "[8/10] Stopping service for upgrade..."
    if systemctl is-active --quiet omnicloud; then
        systemctl stop omnicloud
        echo -e "${GREEN}✓ Service stopped${NC}"
    else
        echo -e "${YELLOW}Service not running${NC}"
    fi
else
    echo ""
    echo "[8/10] Skipping service stop (fresh install)"
fi

# Step 9: Install binary
echo ""
echo "[9/10] Installing binary..."
cp omnicloud /opt/omnicloud/bin/omnicloud
chmod +x /opt/omnicloud/bin/omnicloud
chown omnicloud:omnicloud /opt/omnicloud/bin/omnicloud
echo -e "${GREEN}✓ Binary installed to /opt/omnicloud/bin/omnicloud${NC}"

# Save version info
echo "$LATEST_VERSION" > /etc/omnicloud/version
chown omnicloud:omnicloud /etc/omnicloud/version

# Fix library directory permissions
# This ensures all configured library/download paths are writable by the omnicloud user
echo ""
echo "Fixing library directory permissions..."

# Helper function to fix a directory's permissions and verify writability
fix_directory() {
    local DIR="$1"
    local LABEL="$2"
    if [ -z "$DIR" ]; then return; fi

    # Create directory if it doesn't exist
    mkdir -p "$DIR" 2>/dev/null || true
    if [ ! -d "$DIR" ]; then
        echo -e "${RED}  ✗ Could not create $LABEL: $DIR${NC}"
        return
    fi

    # Fix ownership and permissions
    chown -R omnicloud:omnicloud "$DIR" 2>/dev/null || true
    chmod -R 755 "$DIR" 2>/dev/null || true

    # Verify writability by testing a file write
    TEST_FILE="$DIR/.omnicloud-write-test-$$"
    if su -s /bin/sh omnicloud -c "touch '$TEST_FILE'" 2>/dev/null; then
        rm -f "$TEST_FILE" 2>/dev/null
        echo -e "${GREEN}  ✓ $LABEL: $DIR (writable)${NC}"
    else
        # Try as root first to see if the filesystem itself is read-only
        if touch "$TEST_FILE" 2>/dev/null; then
            rm -f "$TEST_FILE" 2>/dev/null
            echo -e "${YELLOW}  ⚠ $LABEL: $DIR (writable as root, re-fixing ownership)${NC}"
            chown -R omnicloud:omnicloud "$DIR" 2>/dev/null || true
            chmod -R 755 "$DIR" 2>/dev/null || true
        else
            echo -e "${RED}  ✗ $LABEL: $DIR is on a READ-ONLY filesystem!${NC}"
            # Try to find and remount the filesystem read-write
            MOUNT_POINT=$(df "$DIR" 2>/dev/null | tail -1 | awk '{print $NF}')
            MOUNT_DEV=$(df "$DIR" 2>/dev/null | tail -1 | awk '{print $1}')
            if [ -n "$MOUNT_POINT" ] && [ -n "$MOUNT_DEV" ]; then
                echo -e "${YELLOW}    Attempting to remount $MOUNT_POINT read-write...${NC}"
                if mount -o remount,rw "$MOUNT_DEV" "$MOUNT_POINT" 2>/dev/null; then
                    chown -R omnicloud:omnicloud "$DIR" 2>/dev/null || true
                    chmod -R 755 "$DIR" 2>/dev/null || true
                    echo -e "${GREEN}    ✓ Remounted $MOUNT_POINT as read-write${NC}"
                else
                    echo -e "${RED}    ✗ Could not remount. You may need to manually fix this:${NC}"
                    echo -e "${RED}      sudo mount -o remount,rw $MOUNT_DEV $MOUNT_POINT${NC}"
                    echo -e "${RED}      sudo chown -R omnicloud:omnicloud $DIR${NC}"
                fi
            fi
        fi
    fi
}

# Read scan_path from existing config
SCAN_PATH=""
if [ -f /opt/omnicloud/auth.config ]; then
    SCAN_PATH=$(grep "^scan_path=" /opt/omnicloud/auth.config | cut -d'=' -f2)
elif [ -f /opt/OmniCloud/omnicloud2024/omnicloud.config ]; then
    SCAN_PATH=$(grep "^scan_path=" /opt/OmniCloud/omnicloud2024/omnicloud.config | cut -d'=' -f2)
fi

# Try to fetch the torrent download location from the main server
# (the server may have a different download path configured via the UI)
TORRENT_DL_PATH=""
if [ -f /opt/omnicloud/auth.config ]; then
    CONFIG_SERVER_ID=$(grep "^server_id=" /opt/omnicloud/auth.config 2>/dev/null | cut -d'=' -f2)
    CONFIG_MAC=$(ip link show | awk '/ether/ {print $2; exit}')
    if [ -n "$CONFIG_SERVER_ID" ]; then
        TORRENT_DL_PATH=$(curl -fsSL -H "X-Server-ID: $CONFIG_SERVER_ID" -H "X-MAC-Address: $CONFIG_MAC" \
            "${MAIN_SERVER}/api/v1/servers/${CONFIG_SERVER_ID}/settings" 2>/dev/null | \
            grep -o '"torrent_download_location":"[^"]*"' | cut -d'"' -f4) || true
    fi
fi

# Fix base directory
fix_directory "/library/omnicloud" "Base library"

# Fix scan_path directory
if [ -n "$SCAN_PATH" ]; then
    fix_directory "$SCAN_PATH" "Scan path"
fi

# Fix torrent download location from main server
if [ -n "$TORRENT_DL_PATH" ]; then
    fix_directory "$TORRENT_DL_PATH" "Torrent download location"
fi

# Fix ALL directories under /library/omnicloud/ recursively
# This catches any library locations configured via the UI
if [ -d /library/omnicloud ]; then
    chown -R omnicloud:omnicloud /library/omnicloud 2>/dev/null || true
    chmod -R 755 /library/omnicloud 2>/dev/null || true
    echo -e "${GREEN}  ✓ Fixed all permissions under /library/omnicloud/${NC}"
fi

# Also fix torrent data directory permissions
TORRENT_DATA_DIR="/opt/omnicloud/data/torrents"
if [ -f /opt/omnicloud/auth.config ]; then
    CFG_TORRENT_DIR=$(grep "^torrent_data_dir=" /opt/omnicloud/auth.config | cut -d'=' -f2)
    if [ -n "$CFG_TORRENT_DIR" ]; then
        TORRENT_DATA_DIR="$CFG_TORRENT_DIR"
    fi
fi
fix_directory "$TORRENT_DATA_DIR" "Torrent data dir"

# Step 10: Generate/update config
echo ""
echo "[10/10] Configuring..."

if [ -z "${FORCE_NEW_CONFIG:-}" ] && { [ -f /opt/omnicloud/auth.config ] || [ -f /opt/OmniCloud/omnicloud2024/omnicloud.config ]; }; then
    echo -e "${GREEN}✓ Configuration already exists (preserving)${NC}"
else
    # Generate new config
    if [ -n "${REGISTRATION_KEY:-}" ]; then
        REG_KEY="$REGISTRATION_KEY"
        echo -e "${GREEN}Using registration key from environment${NC}"
    else
        REG_KEY=$(openssl rand -hex 32)
        echo -e "${YELLOW}Generated random registration key${NC}"
        echo -e "${YELLOW}⚠  For client mode, get the key from your main server admin${NC}"
    fi

    MAC_ADDRESS=$(ip link show | awk '/ether/ {print $2; exit}')
    HOSTNAME=$(hostname -f)

    # Create config in both locations for compatibility
    cat > /opt/omnicloud/auth.config << EOF
# OmniCloud Client Configuration
# Generated: $(date)

# Database connection
host=localhost
port=5432
database=OmniCloud
user=omni
password=$DB_PASSWORD

# Server configuration
server_mode=client
# Options: "main" for main server, "client" for site servers

# API port (default: 10858)
api_port=10858

# Tracker port (not used on client, only main server needs this)
tracker_port=0

# Torrent data port (not used on client)
torrent_data_port=0

# Registration key (must match main server's key)
registration_key=$REG_KEY

# Main server URL (REQUIRED for client mode)
main_server_url=$MAIN_SERVER

# DCP archive path (default library location, can be overridden via server settings UI)
scan_path=/library/omnicloud/OmniCloudAPPLibrary

# Torrent data directory (must be writable by omnicloud user)
torrent_data_dir=/opt/omnicloud/data/torrents

# Periodic scan interval in hours
scan_interval=12

# Server identification
server_name=$HOSTNAME
server_location=Unknown Location

# Public tracker URL (leave empty for client, main server will provide)
public_tracker_url=

# Public IP (leave empty for client, will be detected)
public_ip=

# Torrent generation
max_torrent_generation_workers=4
EOF

    chown omnicloud:omnicloud /opt/omnicloud/auth.config
    chmod 600 /opt/omnicloud/auth.config

    # Also create at alternate location for compatibility
    cp /opt/omnicloud/auth.config /opt/OmniCloud/omnicloud2024/omnicloud.config
    chown omnicloud:omnicloud /opt/OmniCloud/omnicloud2024/omnicloud.config
    chmod 600 /opt/OmniCloud/omnicloud2024/omnicloud.config

    echo -e "${GREEN}✓ Configuration created at /opt/omnicloud/auth.config${NC}"
    echo -e "${GREEN}✓ Configuration also created at /opt/OmniCloud/omnicloud2024/omnicloud.config${NC}"
fi

# Install systemd service (always write the latest version with correct ReadWritePaths)
cat > /etc/systemd/system/omnicloud.service << 'SERVICEEOF'
[Unit]
Description=OmniCloud DCP Manager
Documentation=https://github.com/omnicloud/omnicloud
After=network.target postgresql.service
Wants=postgresql.service

[Service]
Type=simple
User=omnicloud
Group=omnicloud
WorkingDirectory=/opt/omnicloud
ExecStart=/opt/omnicloud/bin/omnicloud
ExecReload=/bin/kill -HUP $MAINPID
Restart=on-failure
RestartSec=10s
KillMode=process
KillSignal=SIGTERM
TimeoutStopSec=30s

# Environment
Environment=OMNICLOUD_LOG_FILE=/var/log/omnicloud/omnicloud.log

# Security hardening
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/opt/omnicloud /var/log/omnicloud /tmp /library/omnicloud

# Resource limits
LimitNOFILE=65536
LimitNPROC=4096

[Install]
WantedBy=multi-user.target
SERVICEEOF
systemctl daemon-reload
echo -e "${GREEN}✓ Systemd service installed (with /library/omnicloud write access)${NC}"

# Enable and start service
systemctl enable omnicloud 2>/dev/null || true

if [ "$INSTALL_TYPE" = "upgrade" ]; then
    echo ""
    echo "Starting service..."
    systemctl start omnicloud
    echo -e "${GREEN}✓ Service started${NC}"
fi

# Setup log rotation (if not exists)
if [ ! -f /etc/logrotate.d/omnicloud ]; then
    cat > /etc/logrotate.d/omnicloud << 'EOF'
/var/log/omnicloud/*.log {
    daily
    rotate 14
    compress
    delaycompress
    notifempty
    missingok
    create 0640 omnicloud omnicloud
    sharedscripts
    postrotate
        systemctl reload omnicloud > /dev/null 2>&1 || true
    endscript
}
EOF
    echo -e "${GREEN}✓ Log rotation configured${NC}"
fi

# Final output
echo ""
echo "=========================================="
if [ "$INSTALL_TYPE" = "upgrade" ]; then
    echo -e "${GREEN}✓ OmniCloud upgraded successfully!${NC}"
    echo -e "${GREEN}   ${CURRENT_VERSION:-unknown} → ${LATEST_VERSION}${NC}"
else
    echo -e "${GREEN}✓ OmniCloud installed successfully!${NC}"
    echo -e "${GREEN}   Version: ${LATEST_VERSION}${NC}"
fi
echo "=========================================="
echo ""

if [ "$INSTALL_TYPE" = "install" ]; then
    echo "Next steps:"
    echo "1. Edit configuration: vi /etc/omnicloud/auth.config"
    echo "   - Verify main_server_url: $MAIN_SERVER"
    echo "   - Set registration_key (get from main server admin)"
    echo "   - Set scan_path to your DCP library"
    echo "   - Update server_name and server_location"
    echo ""
    echo "2. Start the service:"
    echo "   systemctl start omnicloud"
    echo ""
else
    echo "Service status:"
    systemctl status omnicloud --no-pager -l || true
    echo ""
fi

echo "Useful commands:"
echo "  Status:  systemctl status omnicloud"
echo "  Logs:    journalctl -u omnicloud -f"
echo "  Test:    curl http://localhost:10858/api/v1/health"
echo "  Upgrade: curl -fsSL http://dcp1.omniplex.services:10858/install | sudo bash"
echo ""
echo "=========================================="

# OmniCloud DCP Manager v20260216-205705

Built: 2026-02-16T20:57:05Z

## Installation

For new installations:
```bash
sudo ./install.sh
```

For upgrades on existing installations:
The update agent will handle this automatically, or run:
```bash
sudo systemctl stop omnicloud
sudo cp omnicloud /opt/omnicloud/bin/omnicloud
sudo systemctl start omnicloud
```

## Configuration

Edit /etc/omnicloud/auth.config with your settings.

## Service Management

- Start: `sudo systemctl start omnicloud`
- Stop: `sudo systemctl stop omnicloud`
- Restart: `sudo systemctl restart omnicloud`
- Status: `sudo systemctl status omnicloud`
- Logs: `sudo journalctl -u omnicloud -f`

For more information, visit: https://github.com/omnicloud/omnicloud
